CacaoTuneLibrary 1.0.10（Windows 版・x64: Intel / AMD の Windows 用）

CacaoTuneLibrary.exe をダブルクリックで起動します（インストール不要）。
Windows 10 / 11。WebView2 が必要です（Windows 11 と、更新された Windows 10 には入っています）。

最初に開くとき SmartScreen の警告が出たら「詳細情報」→「実行」を押してください（署名していないため）。
起動したら、窓の下の「GitHub から用意する」を押すと、yt-dlp・ffmpeg・deno を自動で取ってきます。

自分で聴くためだけにお使いください。
https://github.com/ICTCacao/CacaoTuneLibrary
